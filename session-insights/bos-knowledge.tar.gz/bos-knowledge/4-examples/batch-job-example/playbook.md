# GL Reconciliation Batch Job Playbook

**Service:** Auto Lending GL Reconciliation
**Job Code:** `AL_REG_EOD_REPORT_GEN`
**Criticality:** T1 (Critical)
**SLA:** Report available by 6:00 AM EST

---

## Quick Reference

| Item | Value |
|------|-------|
| **Scheduled Start** | 2:00 AM EST daily |
| **Normal Duration** | 45 minutes |
| **Max Duration** | 60 minutes |
| **SLA Deadline** | 6:00 AM EST |
| **Business Owner** | Jane Doe (VP, Operations) |
| **Technical Owner** | FinTech_Data_Platform |
| **Support Email** | sre-fintech-data@company.com |
| **PagerDuty** | PD_SERVICE_XYZ |
| **ServiceNow Group** | Auto_Lending_L2_Support |

---

## Business Context

### What This Job Does

The GL Reconciliation job aggregates daily transaction logs from the Auto Lending core banking platform, formats them according to regulatory requirements, and transmits the reconciliation report to the regulatory file gateway.

### Why It Matters

| Impact Category | Consequence of Failure |
|-----------------|----------------------|
| **Regulatory** | Non-compliance; $10K-$50K penalties per occurrence |
| **Financial** | $125K average quarterly adjustments from undetected errors |
| **Customer** | Potential 48-72hr origination freeze affecting ~2,400 applications |
| **Operational** | 2.5 hours unplanned work; executive notification required |

### Key Stakeholders to Notify

| Stakeholder | When to Notify | Contact |
|-------------|----------------|---------|
| VP Operations | SLA at risk (5:30 AM) or breach | jane.doe@company.com |
| Finance Team | Reconciliation variance detected | finance-team@company.com |
| Compliance | SLA breach confirmed | compliance-team@company.com |

---

## Triage Guide

### Job Not Started by 2:15 AM

**Symptoms:** No scheduler start event logged by 2:15 AM

**Check:**
1. Scheduler status: `autorep -J AL_REG_EOD_REPORT_GEN`
2. Upstream dependencies: Are predecessor jobs complete?
3. Resource availability: Is the execution server responsive?

**Resolution:**
- If scheduler issue: Restart scheduler agent on execution server
- If upstream delay: Monitor predecessor job, adjust expectations
- If server issue: Failover to backup execution server

**Escalation:** If not started by 2:30 AM, page on-call SRE

---

### Job Running Longer Than Expected

**Symptoms:** Duration exceeds 50 minutes (normal: 45 min)

**Check:**
1. Current progress: Check job log for record count
2. Database performance: Query data warehouse execution times
3. Network throughput: S3 read speeds

**Resolution:**
- If database slow: Check for competing queries, resource contention
- If S3 slow: Verify no throttling, check bucket metrics
- If processing slow: May be higher-than-normal transaction volume (acceptable)

**Escalation:** If still running at 5:00 AM, prepare for manual intervention

---

### Known Error: ORA-00054 (Resource Busy)

**Error String:** `ORA-00054: resource busy and acquire with NOWAIT specified`

**Root Cause:** Table lock in Oracle source database

**Automated Resolution:** Job will automatically retry after 5 minutes

**Manual Resolution (if auto-retry fails):**
```sql
-- Find locking session
SELECT s.sid, s.serial#, s.username, s.program
FROM v$session s, v$lock l
WHERE s.sid = l.sid AND l.type = 'TM';

-- Kill blocking session (with DBA approval)
ALTER SYSTEM KILL SESSION 'sid,serial#' IMMEDIATE;
```

**Prevention:** Schedule job to avoid conflict with overnight batch maintenance windows

---

### Known Error: Connection Refused (SFTP)

**Error String:** `Connection refused` or `Connection timed out`

**Root Cause:** SFTP Gateway unavailable

**Check:**
1. Gateway status dashboard
2. Network connectivity: `telnet regulatory-gateway.company.net 22`
3. Recent changes: Check change calendar for gateway maintenance

**Resolution:**
- If gateway down: Escalate to Gateway Operations team
- If network issue: Escalate to Network Operations
- If maintenance: Wait for completion, then restart job

**Workaround:** If gateway team cannot restore in time, file can be delivered via secure email to regulatory contact (requires VP approval)

---

### Reconciliation Variance Detected

**Symptoms:** Report totals differ from source by more than $0.01

**Check:**
1. Transaction count: Does report include all expected records?
2. Date range: Is the query window correct (previous business day)?
3. Currency precision: Are calculations handling decimal precision correctly?

**Investigation Query:**
```sql
-- Compare report total to source
SELECT
    report.total_amount AS report_total,
    source.total_amount AS source_total,
    ABS(report.total_amount - source.total_amount) AS variance
FROM gl_recon_report report
JOIN DATA_WAREHOUSE.CORE_BANKING.TRANS_LOGS_DAILY_AGG source
ON report.report_date = source.trans_date;
```

**Resolution:**
- If missing records: Rerun with corrected date range
- If calculation error: Fix logic, reprocess
- If source data issue: Escalate to core banking team

**Important:** Do NOT submit report with known variance without Finance team approval

---

## Emergency Procedures

### SLA Breach Imminent (5:30 AM, Job Not Complete)

1. **Page business owner** - inform of likely breach
2. **Assess completion time** - is job close to finishing or stuck?
3. **Prepare notification** - draft regulatory delay notice
4. **Executive notification** - inform VP of situation

### SLA Breached (6:00 AM, Report Not Delivered)

1. **Confirm breach** - verify report not received at gateway
2. **Notify compliance** - regulatory team must log the delay
3. **Executive notification** - VP must be informed within 30 minutes
4. **Continue remediation** - complete job and deliver report
5. **Incident report** - document timeline and root cause within 4 hours

### Report Delivered But Data Quality Issue Suspected

1. **Do NOT notify regulators yet** - report is technically on time
2. **Verify data quality** - run reconciliation checks
3. **If variance found** - notify Finance team immediately
4. **If correction needed** - file amended report with explanation

---

## Recovery Procedures

### Safe Restart

This job is **idempotent** and **safe to restart**.

```bash
# Restart job via scheduler
sendevent -E FORCE_STARTJOB -J AL_REG_EOD_REPORT_GEN
```

**Pre-restart checklist:**
- [ ] Root cause of failure identified or mitigated
- [ ] Source systems (data warehouse, S3) accessible
- [ ] SFTP gateway responsive
- [ ] Sufficient time remaining before SLA

### Manual Data Recovery

If job cannot complete normally:

1. **Extract data manually:**
   ```sql
   SELECT * FROM DATA_WAREHOUSE.CORE_BANKING.TRANS_LOGS
   WHERE trans_date = CURRENT_DATE - 1;
   ```

2. **Format report:** Use template in `/shared/templates/gl_recon_template.xlsx`

3. **Transmit manually:** Use secure file transfer to gateway (requires VP approval)

4. **Log exception:** Document manual process in ServiceNow incident

---

## Contacts

| Role | Name | Contact | When to Reach |
|------|------|---------|---------------|
| On-Call SRE | Rotating | PagerDuty: PD_SERVICE_XYZ | Any job failure |
| Technical Lead | TBD | sre-fintech-data@company.com | Escalation |
| Business Owner | Jane Doe | jane.doe@company.com | SLA at risk |
| Finance Contact | TBD | finance-team@company.com | Reconciliation issues |
| Compliance | TBD | compliance-team@company.com | SLA breach |
| Gateway Ops | TBD | gateway-ops@company.com | SFTP issues |

---

## Revision History

| Date | Version | Author | Changes |
|------|---------|--------|---------|
| 2026-01-09 | 1.0 | BOS Pilot Team | Initial version from BOS onboarding |

---

*This playbook was generated from BOS structured data.*
