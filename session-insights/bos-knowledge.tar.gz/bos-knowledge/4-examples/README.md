# BOS Examples - Worked Examples

**Purpose:** Complete examples showing BOS applied to real service types.

**Contents:**
- `batch-job-example/` - GL Reconciliation batch job (regulatory reporting)
  - `bos-metadata.yaml` - Complete BOS metadata file
  - `playbook.md` - Generated runbook
- `api-service-example/` - Credit Check API service (coming soon)

---

## How to Use These Examples

1. **Read the YAML** - See how BOS captures service context
2. **Review the Playbook** - See what BOS produces
3. **Compare Layers** - Notice System → Process → Business Health → Business Impact progression
4. **Adapt to Your Service** - Use as template for your own services

---

## What Makes These Examples Valuable

### Batch Job Example (GL Reconciliation)
- **Regulatory deadline** (6:00 AM SLA)
- **Multiple stakeholders** (regulators, operations, finance, customers)
- **All four signal layers** represented
- **Known error patterns** with recovery procedures
- **Data lineage** showing inputs/outputs

### API Service Example (Credit Check)
- **Real-time SLO** (latency + success rate)
- **Customer-facing impact** quantification
- **Error budget** approach
- **Common integration patterns**

---

## Key Patterns to Notice

1. **Stakeholder Expectations** - Each has clear impact category
2. **Four-Layer Signals** - System supports Process supports Business Health, Impact quantifies failure
3. **Business Impact** - Always includes at least one of: Customer, Financial, Legal/Risk, Operational
4. **Playbook Integration** - Every known error has recovery procedure
