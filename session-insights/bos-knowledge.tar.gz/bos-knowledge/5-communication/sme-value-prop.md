# What You'll Get From This Conversation

**Your time:** 30-45 minutes
**What we're doing:** Capturing business context for your service (whether that's a batch job, API, workflow, or other process) so monitoring can be smarter

---

## The Problem We're Solving

When something fails at 2am, the on-call person sees:

> **ALERT:** `GL_RECONCILIATION_JOB` failed

They don't know:
- Who cares about this?
- How urgent is it really?
- What's the business impact?
- Who should they call?

So they either wake everyone up (annoying) or wait until morning (risky).

---

## What We Need From You

We'll ask about four things:

| Topic | Example Questions |
|-------|-------------------|
| **Who depends on this?** | Which teams or stakeholders need the output? |
| **What do they expect?** | When do they need it? What accuracy? |
| **What happens when it fails?** | Who gets blocked? Any regulatory deadlines? |
| **How do you know it's working?** | What does "success" look like? |

You know your system better than anyone. We're capturing that knowledge so it doesn't live only in your head.

---

## What You Get Back

From one conversation, we generate:

### 1. A Dashboard Panel
Shows health with business context — not just "running/failed" but "on track to meet Finance's 6am deadline."

**What you'll see:**
```
┌─────────────────────────────────────────────────────────┐
│  GL Reconciliation Job              [T1 CRITICAL] ✓ OK │
├─────────────────────────────────────────────────────────┤
│  SLA Attainment: 99.7%  │  Avg Duration: 43m           │
│  Penalty Exposure: $0   │  Apps at Risk: 0             │
├─────────────────────────────────────────────────────────┤
│  Business Health                                        │
│  ✓ Report Available by 6:00 AM ........ 05:42 AM      │
│  ✓ Reconciliation Accuracy ............ $0.00 var     │
├─────────────────────────────────────────────────────────┤
│  If Failed:  Legal: $10K-$50K  │  Customers: 2,400     │
└─────────────────────────────────────────────────────────┘
```
*Your dashboard shows business outcomes, not just technical status.*

### 2. Smarter Alerts
Instead of generic failure alerts, your on-call team sees:
> **ALERT:** `GL_RECONCILIATION_JOB` failed
> - **Impact:** Finance team blocked, regulatory deadline in 4 hours
> - **Escalate to:** Finance Operations Lead
> - **Runbook:** [link]

### 3. A Runbook
Step-by-step guide for handling incidents — what to check, who to call, how to recover. Written once, used every time.

---

## Why This Helps You

| Before | After |
|--------|-------|
| On-call guesses at priority | On-call knows exact business impact |
| Escalations based on gut feel | Escalations based on documented stakeholders |
| Tribal knowledge in your head | Documented, queryable, maintained |
| Same questions every incident | Runbook answers common questions |

---

## What Happens Next

1. **Today:** We capture business context (this conversation)
2. **This week:** We generate your dashboard, alerts, and runbook
3. **You review:** Make sure we got it right
4. **It's live:** Business-aware monitoring for your service

---

## Quick Answers

**"Who maintains this after the conversation?"**
Your delivery team owns it — same as the service itself. When something changes in a sprint, you review whether the business context changed too. Your Product Owner is accountable for keeping it current.

**"What if things change?"**
Review during the sprint where the change happens. Not every code change — just changes that affect who cares, what they expect, or what happens when it fails.

**"Where does this actually live?"**
The metadata becomes part of your service documentation. The dashboard and alerts integrate with existing monitoring tools.

---

*Questions? The goal is better monitoring, not more paperwork for you.*
