# BOS Communication - Stakeholder Materials

**Purpose:** Materials for explaining BOS to different audiences.

**Contents:**
- `executive-summary.md` - Leadership value proposition
- `sme-value-prop.md` - For SMEs being interviewed during onboarding

---

## When to Use

| Audience | Use... |
|----------|--------|
| Executives, sponsors, leadership | `executive-summary.md` |
| SMEs being interviewed | `sme-value-prop.md` |
| Technical evaluators | Point to `2-concepts/` and examples |
| Workshop participants | Point to `3-implementation/` |
