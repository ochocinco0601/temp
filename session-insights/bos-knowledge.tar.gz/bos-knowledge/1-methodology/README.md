# BOS Methodology - Core Concepts

**Purpose:** Foundational principles defining what Business Observability is and how it works.

**Read Order:**
1. `foundational-principles.md` - Start here (Core Principle, Logic Model, Semantic Flow)
2. `four-layer-model.md` - Signal classification framework
3. `factory-model.md` - How BOS scales through artifact production
4. `implementation-architecture.md` - 5-layer dependency model

---

## Quick Summary

| Concept | One-Line Description |
|---------|---------------------|
| **Core Principle** | Business observability begins with defining success in business health terms |
| **Logic Model** | If we want to know whether a problem is solved, we must treat the business goal as a requirement |
| **Semantic Flow** | Stakeholder → Expectation → Impact → Telemetry → Signal → Dashboard |
| **Four-Layer Model** | System → Process → Business Health → Business Impact |
| **Factory Model** | Templates → Production Lines → Operational Artifacts |
| **Implementation Architecture** | Business Context (Layer 1) enables all downstream layers |

---

## When to Reference Each Document

| If you need to understand... | Read... |
|------------------------------|---------|
| Why BOS exists and what it does | `foundational-principles.md` |
| How to classify signals | `four-layer-model.md` |
| How BOS produces artifacts at scale | `factory-model.md` |
| Why business context is foundational | `implementation-architecture.md` |
