# Business Observability System (BOS) — Four-Layer Model

**Version:** 2.0
**Audience:** Product Owners, App Dev, Platform SRE, Incident Command
**Purpose:** Define the four observability layers with concrete examples and a clear mental model. Keep dashboards business-first: **Business Health → Business Impact → Process → System → Actions**.

---

## Quick Summary

BOS organizes signals into **four explicit layers**:

| Layer | Name | Purpose | Grouping |
|-------|------|---------|----------|
| 1 | **System** | Infrastructure health | Traditional |
| 2 | **Process** | Application correctness | Traditional |
| 3 | **Business Health** | Outcome attainment | BOS Adds |
| 4 | **Business Impact** | Consequence quantification | BOS Adds |

* **Traditional** (Layers 1-2): Validate the **mechanism** (up, fast, correct). Standard observability.
* **BOS Adds** (Layers 3-4): Validate the **intended outcome** and quantify **consequence** when outcomes miss.
* **Why BOS ≠ just observability:** It adds explicit business success definitions (Layer 3) and structured impact measurement (Layer 4), so numbers connect to meaning and action.

---

## Layer Definitions

### Layer 1: System (Infrastructure Health)

* **Purpose:** Prove infrastructure and platform components are operational.
* **Measure:** Availability, latency, saturation, resource utilization.
* **Question Answered:** "Is the platform operational?"
* **Owners:** SRE, Platform Engineering.
* **Examples:** `Platform_Uptime %`, `p95_latency_ms`, `CPU_utilization`, `Memory_pressure`.

### Layer 2: Process (Application Correctness)

* **Purpose:** Prove application workflows execute correctly and data integrity is maintained.
* **Measure:** Validation rates, step completion, field accuracy, error rates.
* **Question Answered:** "Is the workflow executing correctly?"
* **Owners:** Dev/QA, Application Teams.
* **Examples:** `Field_Accuracy %`, `Batch_Completion_Rate`, `Validation_Pass_Rate`, `Error_Rate`.

### Layer 3: Business Health (Outcome Attainment) — BOS Adds

* **Purpose:** Prove the software is achieving stakeholder expectations right now.
* **Measure:** Stakeholder **expectation** attainment via explicit **KPI**, **target**, and **formula**.
* **Question Answered:** "Is the expectation being met?"
* **Owners:** Product Owner (+ Analytics), with Dev ensuring instrumentation.
* **Examples:** `Fill_Rate %`, `Verification_Pass_Rate %`, `On_Time_Funding_Rate`, `Customer_Approval_Rate`.

### Layer 4: Business Impact (Consequence Quantification) — BOS Adds

* **Purpose:** Quantify consequences when business outcomes miss targets.
* **Measure:** **Consequence** magnitude across four categories: customer, financial, compliance, operational.
* **Question Answered:** "How bad when we fail?"
* **Owners:** Product Owner + Ops/Compliance; surfaced by SRE.
* **Examples:** `customers_affected`, `dollars_at_risk`, `compliance_cases`, `ops_minutes_added`.

---

## Semantic Flow (Conceptual Model)

```
[Stakeholder] → [Expectation]
  → [KPI target + formula]
    → [Business Health Signal (Layer 3)]
      → supported by [Process Signal (Layer 2)] and [System Signal (Layer 1)]
        → if deviation → [Business Impact Signal (Layer 4): category + magnitude]
          → [Alert] → [Owner + Next Action]
```

**Rule:** Business-first framing. Layers 1-2 explain mechanism; Layer 3 validates outcome; Layer 4 quantifies consequence.

---

## Comparative View

| Dimension | Layer 1: System | Layer 2: Process | Layer 3: Business Health | Layer 4: Business Impact |
|-----------|-----------------|------------------|--------------------------|--------------------------|
| **Primary lens** | Infrastructure health | Workflow correctness | Outcome attainment | Consequence quantification |
| **Question** | "Is it up?" | "Is it correct?" | "Is expectation met?" | "How bad when we fail?" |
| **Examples** | `Uptime %`, `p95_latency_ms` | `Field_Accuracy %`, `Batch_Complete` | `Fill_Rate %`, `Pass_Rate %` | `customers_affected`, `$ at risk` |
| **Trigger** | Infra thresholds | App thresholds | KPI thresholds | Activates when KPI breaches |
| **Ownership** | SRE | Dev/QA | Product Owner | PO + Ops/Compliance |
| **Dashboard order** | Bottom | Below Business | First (top) | Prominent in exec tiles |
| **Grouping** | Traditional | Traditional | BOS Adds | BOS Adds |

---

## Concrete Examples

### Layer 1: System (Infrastructure Health)

* `Trading_Platform_Uptime` = **92%** (target ≥ 99.5%)
  *Meaning:* Platform availability is below target; risk of missed trades increases.
* `Order_System_p95_Latency_ms` = **250** (target ≤ 200)
  *Meaning:* Slow path threatens KPI attainment (fill rate, spread).

### Layer 2: Process (Application Correctness)

* `PreTrade_Field_Accuracy` = **99%** (target ≥ 99.9%)
  *Meaning:* Validation drift can cascade into downstream rejections.
* `Batch_Job_Completion_Rate` = **98%** (target ≥ 99.5%)
  *Meaning:* Incomplete batches require manual intervention.

### Layer 3: Business Health (Outcome Attainment)

* `Fill_Rate` = **89%** (target ≥ 90%)
  *Meaning:* Business outcome is not meeting stakeholder expectation.
* `Verification_Pass_Rate` = **94%** (target ≥ 95%)
  *Meaning:* Customers experiencing higher rejection rates than acceptable.

### Layer 4: Business Impact (Consequence Quantification)

* **Customer:** `customers_affected` = **333** (last 15m when `Fill_Rate < 90%`)
  *Meaning:* Counts distinct customers experiencing degraded outcomes now.
* **Financial:** `dollars_at_risk` = **$2,500** (last 30m when `Payment_Validation_Rate < 99%`)
  *Meaning:* Dollarized exposure tied to failed payment attempts.
* **Compliance:** `compliance_cases` = **55** (if `Compliance_Pass_Rate` dips)
  *Meaning:* Potential regulatory exposure requiring escalation.
* **Operational:** `ops_minutes_added` = **+14** per case (backlog growth)
  *Meaning:* Staffing/throughput impact for operations.

---

## Domain Walkthroughs

### Capital Markets — Trading

* **Layer 3 (Business Health):** `Fill_Rate = 89%` (≥ 90%), `Avg_Spread = 6.2 bps` (≤ 8.0), `Compliance_Pass_Rate = 94%` (≥ 95%).
* **Layers 1-2 (Traditional):** `PreTrade_Field_Accuracy = 99%`, `Platform_Uptime = 92%`, `Order_p95 = 250ms`.
* **Layer 4 (Business Impact):** `customers_affected = 333`, `$ at risk = 2,500`, `compliance_cases = 55`.
* **Interpretation:** Layer 3 shows business is not meeting targets; Layers 1-2 indicate probable causes; Layer 4 quantifies priority and who to notify.

### Financial Services — Income & Payment Validation

* **Layer 3:** KPI `Pass_Rate ≥ 95%`, `Validation_Rate ≥ 99%`.
* **Layer 4:** `customers_affected`, `ops_minutes_added` if backlog grows; `$ at risk` for appraisal-fee failures.
* **Interpretation:** Layer 3 defines success; Layers 1-2 pinpoint failure modes; Layer 4 frames consequence and action.

---

## Acceptance Checklist (per Service)

- [ ] `Expectation` is clear and testable.
- [ ] Layer 3 signal has a KPI with target and formula; rendered first on dashboard.
- [ ] Layer 1 and Layer 2 signals exist and are thresholded.
- [ ] Layer 4 impact is quantified in at least one category (customer, financial, compliance, operational).
- [ ] `Alert → Owner → Next Action` is explicit.

---

## Why BOS Needs All Four Layers

1. **Mechanism health ≠ outcome success.**
   *Layers 1-2 can be green while business result is failing; only Layer 3 validates success against target.*

2. **Outcome misses need consequence, not just detection.**
   *Layer 4 quantifies severity and category so leaders can prioritize immediately.*

3. **Speed to meaning drives better operations.**
   *Business-first panels cut minutes-to-clarity; Layers 1-2 explain "why," Layer 3 says "met or not," Layer 4 explains "so what."*

4. **Explicit layers eliminate ambiguity.**
   *Four named layers map directly to schema fields (`observability_layer`, `signal_type`) and dashboard sections.*

---

## Implementation Mapping

| Layer | `observability_layer` | `signal_type` |
|-------|----------------------|---------------|
| 1: System | 'System' | sli_ratio, sli_threshold |
| 2: Process | 'Process' | sli_ratio, sli_threshold |
| 3: Business Health | 'Business' | sli_ratio, sli_threshold |
| 4: Business Impact | (NULL or 'Business') | business_impact |
