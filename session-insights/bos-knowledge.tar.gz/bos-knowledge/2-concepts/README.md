# BOS Concepts - Vocabulary and Entity Model

**Purpose:** Controlled terminology and conceptual entity definitions for BOS.

**Contents:**
- `vocabulary.md` - Controlled terminology for all BOS and organizational concepts
- `entity-relationships.md` - How BOS entities connect (30,000 ft view)

---

## When to Reference

| If you need... | Read... |
|----------------|---------|
| The correct term to use | `vocabulary.md` |
| What a BOS entity is | `entity-relationships.md` |
| How entities relate | `entity-relationships.md` |
| Preferred vs non-preferred terms | `vocabulary.md` |

---

## Key Terminology Quick Reference

| Term | Definition |
|------|------------|
| **BOS Service** | The unit of observability - a business-defined scope with stakeholders, signals, and impacts |
| **Signal** | Quantifiable measurement of service health or business outcome |
| **Stakeholder** | Person or group with interest in service health |
| **Expectation** | What a stakeholder needs from a service |
| **Impact** | Consequence when an expectation is not met |
| **Four-Layer Model** | System → Process → Business Health → Business Impact |
