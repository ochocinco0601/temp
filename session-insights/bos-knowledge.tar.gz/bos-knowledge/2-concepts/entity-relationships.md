# BOS Entity Relationships (Conceptual)

**Purpose**: 30,000 ft structural view of BOS organizational concepts - describes WHAT EXISTS, not how it's stored in databases.

---

## Core Entity Definitions

### Organizational Entities

#### Product Line
**What it is**: Highest organizational construct, representing a complete business domain with executive ownership.

**Attributes**:
- Unique identifier (code)
- Product line name
- Executive owner (stakeholder)
- Business description
- Contains: Multiple Products

**Examples**: Consumer Lending, Treasury Management, Credit Cards

**Relationships**:
- **Contains** → Products (one-to-many)
- **Owned by** → Executive Stakeholder (one-to-one)
- **Displayed in** → Executive Dashboard (one-to-one)

---

#### Product
**What it is**: Business capability or product offering within a Product Line, representing a cohesive set of customer-facing or internal services.

**Attributes**:
- Unique identifier (code)
- Product name
- Business purpose description
- Product owner/leadership
- Belongs to: One Product Line

**Examples**: Loan Originations, Auto Finance, Wire Transfers, Card Acquisitions

**Relationships**:
- **Belongs to** → Product Line (many-to-one)
- **Contains** → BOS Services (one-to-many)
- **Displayed in** → Product Dashboard (one-to-one)

---

### Infrastructure Entities

#### CMDB Application
**What it is**: Business application recorded in Configuration Management Database with technical metadata and ownership.

**Attributes**:
- Application ID (app_id)
- Application name
- Description
- Owner team
- Technical owner (email)
- Business owner (email)
- Lifecycle status (production, retired, etc.)
- Criticality level (high, medium, low)
- Last sync timestamp

**Examples**: APP001 "wire-transfer-engine", APP015 "loan-origination-system", APP004 "credit-bureau-gateway"

**Key Characteristic**: CMDB Applications exist independently of BOS - they are **infrastructure records** that predate BOS implementation.

**Relationships**:
- **Maps to** → BOS Services (many-to-many)
- **Owned by** → Business Unit (many-to-one)
- **Not aligned with** → Product Line/Product Hierarchy (independent structure)

---

### Observability Entities

#### BOS Service
**What it is**: The fundamental unit of observability in BOS - a business-defined scope of instrumentation with explicit stakeholder expectations, signals, and impact definitions.

**Critical Characteristic**: BOS Services are **newly defined** during BOS onboarding - they did not exist as formal entities before. Product Owners decompose CMDB Applications into services for the first time.

**Attributes**:
- Service ID (primary identifier)
- Service name (technical)
- Display name (human-readable)
- Business purpose
- Criticality tier level (1-6)
- Product Owner
- Performance question (business framing)
- Tags (categorization)
- Belongs to: One Product (via organizational linkage)

**Examples**: Credit Check Service, Wire Transfer Execution Service, Document Validation Service

**Relationships**:
- **Belongs to** → Product (many-to-one)
- **Maps to** → CMDB Applications (many-to-many)
- **Defines** → Signal Definitions (one-to-many)
- **Has** → Stakeholder Expectations (one-to-many)
- **Produces** → Telemetry (one-to-many)
- **Displayed in** → Service Detail Dashboard (one-to-one)
- **Owned by** → Product Owner (many-to-one)
- **Implemented by** → Scrum Team (many-to-one)

---

#### Signal Definition
**What it is**: Specification of a quantifiable measurement classified by both observability layer (purpose) and signal type (implementation pattern).

**Four-Layer Model**:

| Layer | Name | Purpose |
|-------|------|---------|
| 1 | System | Infrastructure health |
| 2 | Process | Application correctness |
| 3 | Business Health | Outcome attainment |
| 4 | Business Impact | Consequence quantification |

**Signal Types** (implementation pattern):
1. **SLI Ratio**: Good events / total events (e.g., success rate) - used in Layers 1-3
2. **SLI Threshold**: Value compared to threshold (e.g., latency < 2s) - used in Layers 1-3
3. **Business Impact**: Quantified business consequence (e.g., customers blocked, revenue at risk) - Layer 4

**Attributes**:
- Signal ID
- Signal name
- Observability layer (System, Process, Business Health, Business Impact)
- Signal type (sli_ratio, sli_threshold, business_impact)
- Business question (why this matters)
- Data source
- Query logic
- Target/threshold (for SLIs)
- Impact category (for Layer 4: customer, financial, legal, operational)
- Technical owner
- Belongs to: One BOS Service

**Relationships**:
- **Belongs to** → BOS Service (many-to-one)
- **Produces** → Signal History (one-to-many)
- **Displayed in** → Dashboard Panels (many-to-many)
- **Triggers** → Alerts (one-to-many)

---

#### Stakeholder Expectation
**What it is**: Qualitative description of what a stakeholder group expects from a service and the primary impact if expectation is not met.

**Attributes**:
- Context row ID
- Belongs to: One BOS Service
- Stakeholder type (customer, internal, partner, business_unit, compliance)
- Stakeholder group (specific identification)
- Expectation summary (what they expect)
- Primary impact (what breaks if expectation not met)
- Impact category (customer_experience, financial, legal_risk, operational)
- Priority level (CRITICAL, HIGH, MEDIUM, LOW)

**Key Characteristic**: This is **business context with human source of authority** - Product Owner determines and validates final content. AI can suggest based on domain knowledge and CMDB data; SMEs can contribute knowledge from any role.

**Examples**:
- Stakeholder: Loan applicants (customer) / Expectation: "Credit checks complete quickly" / Impact: "Applications blocked" / Category: customer_experience
- Stakeholder: Treasury team (internal) / Expectation: "Maintain origination volume" / Impact: "Lost loan revenue" / Category: financial

**Relationships**:
- **Belongs to** → BOS Service (many-to-one)
- **References** → Stakeholder Type (lookup)
- **References** → Impact Category (lookup)
- **References** → Priority Level (lookup)

---

## Entity Relationship Diagram

```
Organizational Hierarchy:

[Executive Stakeholder]
        │
        │ owns
        ↓
[Product Line] ──contains──> [Product] ──contains──> [BOS Service]
        │                        │                        │
        │                        │                        │
     displays                 displays                 defines
        │                        │                        │
        ↓                        ↓                        ↓
[Executive Dashboard]    [Product Dashboard]      [Signal Definition]
                                                         │
                                                         │ produces
                                                         ↓
                                                  [Signal History]


Infrastructure Integration:

[CMDB Application] <───maps-to───> [BOS Service]
        │                               │
        │                               │
    owned by                      belongs to
        │                               │
        ↓                               ↓
 [Business Unit]                    [Product]


Observability Artifacts:

[BOS Service]
    │
    ├──> [Signal Definition] ──> [Signal History]
    │                   │
    │                   └──> [Alert] ──> [Playbook]
    │
    ├──> [Stakeholder Expectation] ──> [Impact Category]
    │
    └──> [Service Detail Dashboard] ──> [Product Dashboard] ──> [Executive Dashboard]


Ownership and Responsibility:

[Product Owner] ──owns──> [BOS Service] <──implements── [Scrum Team]
                              │
                              │ designed by
                              ↓
                       [Solution Engineer]
```

---

## Key Conceptual Relationships

### 1. Organizational Containment (Strict Hierarchy)
```
[Product Line] 1──>* [Product] 1──>* [BOS Service]
```
- Each Product belongs to exactly one Product Line
- Each BOS Service belongs to exactly one Product
- This creates organizational traceability for Start of Day reporting

### 2. Infrastructure Mapping (Many-to-Many, Independent)
```
[CMDB Application] *<──>* [BOS Service]
```
- CMDB structure does NOT align with Product Line/Product hierarchy
- One CMDB app can host multiple BOS Services
- One BOS Service can span multiple CMDB apps (distributed services)
- This mapping is **recorded** in BOS but doesn't define organizational structure

### 3. Observability Decomposition (Service-Centric)
```
[BOS Service] 1──>* [Signal Definition] 1──>* [Signal History]
```
- Each Signal Definition belongs to exactly one BOS Service
- Each Signal History point belongs to exactly one Signal Definition
- Signals cannot be "shared" across services (design principle)

### 4. Business Context Definition (Service-Scoped)
```
[BOS Service] 1──>* [Stakeholder Expectation]
```
- Each Stakeholder Expectation belongs to exactly one BOS Service
- Typically 3-5 expectations per service (forces prioritization)
- This is the business context layer requiring PO authority

### 5. Dashboard Hierarchy (Aggregation Path)
```
[Service Detail] ──aggregates-to──> [Product Dashboard] ──aggregates-to──> [Executive Dashboard]
```
- Service signals aggregate to Product health
- Product health aggregates to Product Line health
- Drill-down navigation works bidirectionally

---

## Critical Conceptual Insights

### 1. Services Defined for First Time
**Concept**: Before BOS, organizations have CMDB Applications but no formal Service entities. BOS creates service registry.

**Implication**: Product Owners are making **boundary and naming decisions** during onboarding - BOS becomes authoritative service catalog.

### 2. Two Independent Hierarchies
**Concept**: Product Line → Product → Service (business hierarchy) and CMDB Applications (infrastructure hierarchy) are separate, with many-to-many mapping between them.

**Implication**: Cannot derive organizational structure from CMDB alone - BOS needs its own org model.

### 3. Business Context Non-Derivable
**Concept**: Stakeholder expectations and business impacts cannot be automatically extracted from technical systems.

**Implication**: These entities require explicit Product Owner definition - core value of BOS is capturing this layer.

### 4. Signals Belong to Services
**Concept**: Each signal is scoped to exactly one service - no "shared" or "cross-service" signals in data model.

**Implication**: Service boundaries matter - decomposition decisions affect instrumentation granularity.

### 5. Dashboards Follow Organizational Structure
**Concept**: Dashboard hierarchy mirrors organizational hierarchy, not technical architecture.

**Implication**: Executives drill down by business constructs (product lines, products) not by infrastructure (CMDB apps, clusters).

---

## Implementation Separation

**CRITICAL**: This model describes **conceptual entities and relationships** - what exists in the business domain. It does NOT describe:
- Database tables or schemas (implementation)
- File structures (prototype storage)
- API endpoints or data transfer objects (technical interface)
- Dashboard panel types or query syntax (visualization layer)

**Why Separation Matters**: Implementation may change (different table names, schema restructuring, database migration) while conceptual entities remain stable. This model serves as **design intent** that survives technical evolution.
