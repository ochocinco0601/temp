# BOS System Vocabulary

**Purpose**: Controlled terminology for organizational and BOS concepts to ensure consistency across all documentation and communication.

**Scope**: This vocabulary defines terms for BOTH:
- **Organizational hierarchy**: Product Lines, Products, ownership levels, CMDB Applications
- **BOS conceptual framework**: Signal, Stakeholder, Service (BOS definition), Impact, Expectation, SLI, SLO

These domains are integrated - BOS Services belong to Products, BOS Stakeholders map to organizational owners, etc.

---

## Organizational Hierarchy Terms

| Preferred Term | Non-Preferred Alternatives | Definition | Example |
|----------------|---------------------------|------------|---------|
| **Product Line** | Product Portfolio, Line of Business, LoB | Highest organizational construct, owned by executive stakeholder | Consumer Lending, Treasury Management, Credit Cards |
| **Product** | Business Capability, Application, System | Business capability or product area within a Product Line | Loan Originations, Wire Transfers, Auto Finance |
| **Solution Engineer Level** | L2 Level | Level where Solution Engineers and Lead Product Owners operate | Individual named: Jane Smith (Solution Engineer for Loan Funding) |
| **Scrum Team Level** | L1 Level | Level where scrum teams perform hands-on development work | Funding Scrum Team, Treasury Development Team |
| **Business Unit** | Organization, Department | General term for organizational grouping | Consumer Technology, Platform Operations |

## Service Hierarchy Terms

| Preferred Term | Non-Preferred Alternatives | Definition | Example |
|----------------|---------------------------|------------|---------|
| **BOS Service** | Monitored Service, Instrumented Service | The observability scope defined by Product Owner in BOS system - the unit of instrumentation and measurement | Credit Check Service, Wire Transfer Execution Service |
| **CMDB Application** | Configuration Item, CI, Application | Business application recorded in ServiceNow/CMDB with APP_ID identifier | APP001: wire-transfer-engine, APP015: loan-origination-system |
| **Service** (general) | - | Can refer to either BOS Service or underlying technical service depending on context - clarify when ambiguous | - |

## CMDB-to-BOS Relationship Terms

| Preferred Term | Non-Preferred Alternatives | Definition | Business Context |
|----------------|---------------------------|------------|------------------|
| **Map** (verb) | Link, Associate, Connect | Describe the relationship between CMDB Application and BOS Service | "The Credit Check Service maps to APP004: credit-bureau-gateway" |
| **Many-to-Many Mapping** | - | Single CMDB Application can contain multiple BOS Services; single BOS Service can span multiple CMDB Applications | One application hosts multiple services; one distributed service uses multiple applications |
| **App ID** | Application ID | Unique identifier from ServiceNow CMDB for business applications | APP001, APP015 |

### Critical Distinction: CMDB Applications vs BOS Services

**Key Insight**: Services are **not pre-defined in CMDB**. CMDB contains Applications with technical metadata, but individual services within those applications have never been formally defined until BOS.

**Implication**: Product Owners are **defining service boundaries for the first time** when onboarding to BOS - this makes BOS the de facto service registry.

---

## BOS Core Concepts

### Four-Layer Model

BOS organizes signals into four explicit layers. See `1-methodology/four-layer-model.md` for complete framework.

| Layer | Name | Purpose | Grouping |
|-------|------|---------|----------|
| 1 | **System** | Infrastructure health | Traditional |
| 2 | **Process** | Application correctness | Traditional |
| 3 | **Business Health** | Outcome attainment | BOS Adds |
| 4 | **Business Impact** | Consequence quantification | BOS Adds |

- **Traditional** (Layers 1-2): Standard observability familiar to SRE teams
- **BOS Adds** (Layers 3-4): Business observability unique to BOS methodology

### Signal Terminology

| Preferred Term | Non-Preferred Alternatives | Definition | Example |
|----------------|---------------------------|------------|---------|
| **Signal** | Metric, Indicator, Measure | Quantifiable measurement of service health or business outcome | Credit check success rate, wire transfer latency |
| **Observability Layer** | Signal Category | Which of the four layers a signal belongs to (System, Process, Business Health, Business Impact) | Layer 3: Business Health |
| **Signal Type** | - | How signal is measured (implementation pattern) | sli_ratio, sli_threshold, business_impact |
| **SLI** (Service Level Indicator) | Technical Signal, Performance Metric | Quantifiable measure of service health (Layers 1-3) | Availability %, P95 latency, success rate |
| **Business Impact Signal** | Business Metric, Business Signal | Quantifiable measure of business consequence when service degrades (Layer 4) | Customers blocked, revenue at risk, compliance cases |
| **Impact Category** | Consequence Type, Impact Type | Standardized classification of business impact | Customer Experience, Financial, Legal/Risk, Operational |

## Stakeholder Terms

| Preferred Term | Non-Preferred Alternatives | Definition | Example |
|----------------|---------------------------|------------|---------|
| **Stakeholder** | Affected Party, Interested Party | Person or group with interest in service health | Loan applicants (customers), Treasury team (internal), Credit bureaus (partners) |
| **Stakeholder Type** | - | Classification of stakeholder relationship | Customer, Internal, Partner, Business Unit, Compliance |
| **Product Owner** | PO, Business Owner | Person responsible for defining business observability requirements for a BOS Service | Jane Smith (owns Loan Funding Service observability) |
| **Technical Owner** | Dev Lead, Engineering Owner | Person responsible for implementing signals and maintaining instrumentation | Bob Johnson (implements Credit Check signals) |

## BOS Artifacts

| Preferred Term | Non-Preferred Alternatives | Definition | Example |
|----------------|---------------------------|------------|---------|
| **Dashboard** | Visualization, Monitor | Dashboard displaying service health and business impact | Executive Dashboard, Service Detail Dashboard |
| **Alert** | Notification, Alarm | Automated notification when signal violates threshold | Credit Check SLO violation alert |
| **Playbook** | Runbook, Response Guide | Documented procedure for responding to service issues | Credit Check Service degradation playbook |
| **Template** | Form, Worksheet | Structured template for defining service observability metadata | services template, signal_definitions template |

## BOS Process Terms

| Preferred Term | Non-Preferred Alternatives | Definition | Business Context |
|----------------|---------------------------|------------|------------------|
| **Onboarding** | Service Registration | Process of defining a service in BOS for the first time | Product Owner completes structured templates |
| **Enrichment** | Enhancement, Augmentation | Adding business context to technical data | AI suggests stakeholder expectations, PO validates |
| **Data Mining** | Auto-discovery, Pre-population | Extracting technical metadata from existing systems | Pull service names from CMDB, queries from logs |
| **Start of Day** | Morning Check, Status Review | Daily executive meeting reviewing service health across Product Lines | Executive reviews dashboard summaries |

---

## Usage Guidelines

### When to Use This Vocabulary

**Always use preferred terms in**:
- All BOS documentation (guides, READMEs, design docs)
- Stakeholder communications (presentations, emails)
- Dashboard labels and UI text
- Template headers and field names
- Code comments and variable names (when practical)

**Clarify context when**:
- Using "Service" without qualifier (specify: BOS Service, CMDB Application, or technical service)
- Discussing organizational levels (always specify level)
- Referencing external systems (specify: CMDB, Splunk, Grafana, etc.)

### Terminology Consistency Checklist

Before publishing documentation, verify:
- [ ] Organizational levels used consistently
- [ ] "BOS Service" used for observability scope (not "monitored service")
- [ ] "CMDB Application" used for ServiceNow records (not "CI" or "app")
- [ ] "Signal" used for measurements (not mixing "metric" and "signal")
