# BOS Implementation - Practical Guides

**Purpose:** How to apply BOS methodology in practice.

**Contents:**
- `quick-start-reference.md` - 5-minute process, essential templates, query patterns
- `onboarding-workflow.md` - Step-by-step service onboarding guide

---

## When to Use

| If you need... | Read... |
|----------------|---------|
| To quickly define a service | `quick-start-reference.md` |
| SQL/Splunk query templates | `quick-start-reference.md` |
| The 10 essential fields | `quick-start-reference.md` |
| Step-by-step onboarding | `onboarding-workflow.md` |

---

## The 5-Minute BOS Process

1. **Define Success** - What percentage should succeed?
2. **Identify Good Events** - What makes a single event "good"?
3. **Find the Data** - Where does this data live?
4. **Define Impact** - Who can't do what when this fails?
5. **Write the Query** - Calculate success rate
