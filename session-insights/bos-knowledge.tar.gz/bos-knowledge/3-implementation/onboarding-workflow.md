# BOS Service Onboarding Workflow

**Purpose:** Step-by-step guide for onboarding a new service to BOS.

---

## Overview

BOS onboarding captures business context for a service so that monitoring reflects business outcomes, not just technical metrics.

**Time Required:** 30-60 minutes for initial capture
**Participants:** Product Owner (required), Developer (for technical fields), SMEs (optional)

---

## Phase 1: Service Identity (10 minutes)

### Questions to Answer

| Question | Who Answers | Example |
|----------|-------------|---------|
| What is the service called? | PO | Credit Check Service |
| What does it do in one sentence? | PO | Validates customer creditworthiness for loan decisions |
| What product/business area owns it? | PO | Consumer Lending - Loan Originations |
| How critical is it? (T1/T2/T3) | PO | T1 - Critical |

### Output
- Service ID
- Display name
- Business purpose statement
- Organizational linkage
- Criticality tier

---

## Phase 2: Stakeholder Expectations (15 minutes)

### Questions to Answer

For each stakeholder group (typically 3-5):

| Question | Example Answer |
|----------|---------------|
| **Who depends on this?** | Loan applicants (customers) |
| **What do they expect?** | Credit check returns result within 30 seconds |
| **What happens if we fail them?** | Application blocked, customer frustrated |
| **Which impact category?** | Customer Experience |
| **How important?** | CRITICAL |

### Common Stakeholder Types
- **Customer**: End users who interact with the service
- **Internal**: Teams within the organization who depend on the service
- **Partner**: External organizations who integrate with the service
- **Compliance**: Regulatory bodies or internal audit
- **Business Unit**: Organizational units with financial interest

### Output
- 3-5 stakeholder expectation records
- Each with: stakeholder group, expectation, impact, category, priority

---

## Phase 3: Signal Definition (20 minutes)

### Layer 3: Business Health Signal (Required)

Define the primary business outcome measurement:

| Field | Example |
|-------|---------|
| **Signal Name** | Credit Check Success Rate |
| **Business Question** | What percentage of credit checks return a valid score? |
| **Good Condition (PO)** | Status = SUCCESS and score is not null |
| **Target** | 99.5% |
| **Time Window** | Rolling 1 hour |

### Layer 4: Business Impact Signals (Required)

Define at least one impact measurement:

| Category | Signal Name | Example Value |
|----------|-------------|---------------|
| **Customer** | Applications Blocked | Count of failed checks |
| **Financial** | Revenue at Risk | $ value of pending loans |
| **Legal/Risk** | Compliance Cases | Count of regulatory issues |
| **Operational** | Manual Interventions | Hours of unplanned work |

### Layers 1-2: System/Process Signals (Optional but Recommended)

Technical signals that explain business outcomes:

| Layer | Signal | Example |
|-------|--------|---------|
| System | API Availability | 99.9% uptime |
| System | Response Time p95 | < 500ms |
| Process | Validation Pass Rate | 99% |
| Process | Error Rate | < 1% |

### Output
- At least 1 Layer 3 signal (business health)
- At least 1 Layer 4 signal (business impact)
- Optional Layer 1-2 signals (system/process)

---

## Phase 4: Technical Details (15 minutes)

### Developer Populates

| Field | Description | Example |
|-------|-------------|---------|
| **Data Source** | Where does signal data come from? | Oracle database, Splunk logs |
| **Good Events Query** | SQL/Splunk for good events | `status='SUCCESS' AND score IS NOT NULL` |
| **Total Events Query** | SQL/Splunk for total events | `SELECT COUNT(*) FROM credit_checks` |
| **Alert Threshold** | When to page | < 99% for 5 minutes |
| **Dashboard Location** | Where to display | Service detail dashboard |

### Output
- Executable queries for each signal
- Alert thresholds
- Data source configuration

---

## Phase 5: Operational Metadata (5 minutes)

### Questions to Answer

| Question | Example |
|----------|---------|
| **Who is the Product Owner?** | Jane Smith (jane.smith@company.com) |
| **Who is the Technical Owner?** | Credit Check Dev Team |
| **What's the alert routing?** | PagerDuty service XYZ |
| **Where's the runbook?** | ServiceNow KB0012345 |

### Output
- Ownership contacts
- Alert routing configuration
- Documentation links

---

## Validation Checklist

Before marking onboarding complete:

- [ ] Service has clear business purpose
- [ ] At least 3 stakeholder expectations defined
- [ ] Layer 3 (Business Health) signal defined with target
- [ ] Layer 4 (Business Impact) signal defined for at least 1 category
- [ ] Queries are executable (tested against real data)
- [ ] Product Owner has validated all business fields
- [ ] Alert routing is configured
- [ ] Runbook exists or is scheduled for creation

---

## Common Pitfalls to Avoid

| Pitfall | Problem | Solution |
|---------|---------|----------|
| Technical-only signals | "API latency is 500ms" | Add business context: "Causes 12 customers to wait" |
| Vague impacts | "Service is degraded" | Quantify: "27 loan applications blocked" |
| Missing stakeholders | Only technical team listed | Include customers, business partners, compliance |
| Skipping Layer 4 | No impact quantification | Define at least one impact signal |
| No PO validation | Developer guesses at business | PO must review and approve |

---

## After Onboarding

1. **Dashboard Created** - Service appears in organizational dashboard
2. **Alerts Active** - Team receives notifications when SLO breached
3. **Playbook Available** - Incident response documented
4. **Regular Review** - Update when service changes (quarterly minimum)
