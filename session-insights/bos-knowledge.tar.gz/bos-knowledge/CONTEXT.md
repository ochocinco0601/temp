# BOS Knowledge Base - LLM Context File

**Purpose:** This repository contains the Business Observability System (BOS) methodology - a framework for connecting technical monitoring to business outcomes.

**Intended Use:** Reference material for AI assistants (GitHub Copilot, Claude, etc.) to understand and apply BOS concepts when helping with observability, monitoring, dashboards, and service health definitions.

---

## What is BOS?

**Business Observability System (BOS)** is a methodology that transforms technical monitoring into business intelligence. Instead of asking "Is the server up?" BOS asks "Is the business achieving its intended outcomes?"

### The Core Problem BOS Solves

Traditional monitoring tells you:
> "The credit-check-service has a 2% error rate"

BOS tells you:
> "47 loan applications are blocked, impacting $18.8M in potential loans"

The difference: **business context** - who's affected, what they can't do, and what it costs.

### Key Distinguishing Concepts

1. **Four-Layer Model**: Signals organized into System → Process → Business Health → Business Impact
2. **Semantic Flow**: Stakeholder → Expectation → Impact → Telemetry → Signal → Dashboard/Playbook
3. **Factory Model**: Templates → Automated artifact generation at scale
4. **Implementation Architecture**: 5-layer dependency model ensuring business context is foundational

---

## Repository Structure

```
bos-knowledge/
├── CONTEXT.md                    # This file - start here
├── 1-methodology/                # Core BOS concepts (read first)
│   ├── foundational-principles.md    # Core Principle, Logic Model, Semantic Flow
│   ├── four-layer-model.md           # System/Process/Business Health/Business Impact
│   ├── factory-model.md              # BOS as artifact production system
│   └── implementation-architecture.md # 5-layer dependency model
│
├── 2-concepts/                   # BOS vocabulary and entity model
│   ├── vocabulary.md                 # Controlled terminology
│   └── entity-relationships.md       # How BOS concepts connect
│
├── 3-implementation/             # How to apply BOS
│   ├── quick-start-reference.md      # 5-minute process, essential templates
│   └── onboarding-workflow.md        # Step-by-step service onboarding
│
├── 4-examples/                   # Worked examples showing BOS in action
│   ├── batch-job-example/            # GL Reconciliation batch job
│   │   ├── bos-metadata.yaml         # Complete BOS metadata file
│   │   └── playbook.md               # Generated runbook
│   └── api-service-example/          # Credit Check API service
│
└── 5-communication/              # Explaining BOS to stakeholders
    ├── executive-summary.md          # Leadership value proposition
    └── sme-value-prop.md             # For SMEs being interviewed
```

---

## How to Use This Knowledge Base

### For Understanding BOS Methodology
**Start with:** `1-methodology/foundational-principles.md`
- Read the Core Principle, Logic Model, and Semantic Flow
- Then read `four-layer-model.md` to understand signal classification

### For BOS Vocabulary Questions
**Go to:** `2-concepts/vocabulary.md`
- Controlled terminology for all BOS concepts
- Preferred terms vs. non-preferred alternatives

### For Implementing BOS
**Start with:** `3-implementation/quick-start-reference.md`
- 5-minute process for defining a service
- Essential query templates (SQL, Splunk)
- 10 essential fields checklist

### For Seeing BOS Applied
**Look at:** `4-examples/batch-job-example/`
- Complete `bos-metadata.yaml` showing all BOS fields
- Generated `playbook.md` showing operational output

### For Explaining BOS to Others
**Use:** `5-communication/executive-summary.md` or `sme-value-prop.md`

---

## Key Concepts Quick Reference

### Four-Layer Model

| Layer | Name | Question Answered | Example Signal |
|-------|------|-------------------|----------------|
| 1 | System | "Is the platform up?" | Uptime %, p95 latency |
| 2 | Process | "Is the workflow correct?" | Validation rate, error rate |
| 3 | Business Health | "Is the expectation met?" | Success rate vs. target |
| 4 | Business Impact | "How bad when we fail?" | Customers blocked, $ at risk |

**Traditional observability** covers Layers 1-2. **BOS adds** Layers 3-4.

### Semantic Flow

```
[Stakeholder] → has an → [Expectation]
  ...which, if broken, causes an → [Impact]
    ...which is detected by → [Telemetry]
      ...which creates an actionable → [Signal]
        ...which informs both a → [Playbook] and [Dashboard]
```

### Impact Categories

Every business impact falls into one of four categories:
1. **Customer Experience** - Who can't do what?
2. **Financial** - Revenue at risk, costs incurred
3. **Legal/Risk** - Compliance exposure, regulatory penalties
4. **Operational** - Manual work, escalations, firefighting

---

## Anti-Patterns to Avoid

When applying BOS concepts, avoid these common mistakes:

| Anti-Pattern | Problem | Correct Approach |
|--------------|---------|------------------|
| "CPU is at 80%" as business metric | Technical metric, not business outcome | "312 customers experiencing delays" |
| Missing impact quantification | "Service is degraded" is vague | "27 loan applications blocked" |
| Skipping Layer 3-4 | Only monitoring infrastructure | Define business success criteria first |
| No stakeholder identification | Technical focus without business context | "Loan applicants expect 30-second response" |

---

## Principles for Applying BOS

1. **Business First**: Start with stakeholder expectations, work backward to signals
2. **Outcome Over Mechanism**: Layer 1-2 green doesn't mean Layer 3 is healthy
3. **Quantify Impact**: Numbers drive action - "47 customers" beats "some users"
4. **Four Categories**: Every impact fits Customer/Financial/Legal/Operational
5. **Signal Ownership**: Each signal belongs to exactly one service
6. **Dashboard Hierarchy**: L4 (executive) → L3 (product) → Service (detail)

---

## Document Navigation Tips

- **New to BOS?** Start with `1-methodology/foundational-principles.md`
- **Looking for a term?** Check `2-concepts/vocabulary.md`
- **Need to implement?** Use `3-implementation/quick-start-reference.md`
- **Want to see examples?** Browse `4-examples/`
- **Explaining to stakeholders?** Use `5-communication/`

---

*This knowledge base is designed for LLM reference. All content is methodology-focused and enterprise-agnostic.*
